<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="../images/favicon.png">
<!-- CSS -->
<link href="../CSS/tipTip.css" rel="stylesheet" type="text/css" />

<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="../js/jquery.min.js"></script>

<script type="text/javascript" src="../js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="../js/jquery.tipTip.js"></script>
<script type="text/javascript" src="../js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - &iexcl;Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'../menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro">
        
        <BR /><BR />
        <h1 align="center">GENERAL ELECTRIC
        </h1>
        <h1  align="center">&nbsp;</h1><center>
</center>

        <table width="700" border="0">
          <tr>
            <td width="316" align="center"><h2>MONITOR S/5 LIGHT</h2></td>
            <td width="374"><h2 align="center">Especificaciones</h2></td>
          </tr>
          <tr>
            <td><img src="../images/productos/9.jpg" alt="" width="272" height="320" /></td>
            <td align="justify">El Light Monitor S/5 de GE es un monitor de signos vitales compacto y portátil, apto para cuidados críticos, anestesia y traslados. De manejo fácil e intuitivo. Integrable en la Red de GE Datex-Ohmeda para la monitorización central. Pantalla LCD color de 9 &ldquo; de excelente visibilidad y definición. Cuatro ondas simultaneas en pantalla. Robusta estructura para operar en condiciones difíciles. Configurable con los siguientes parámetros ECG, Respiración, SpO2, PANI, Temperatura, 2 x presión sanguínea invasiva (opcional), Fi/EtCO2 (opcional), registrador (opcional), módulo de baterías de dos horas (opcional).</td>
          </tr>
        </table>
        <p><br /> 
  <br /> 
        </p>
        <p align="center"><a href="javascript:history.back(1)" class="someClass" title="Regresar a la pagina anterior" >&lt;&lt; Regresar</a></p>
<br /> 
<br /> 
        
        </div>
       
       
       
       
       
       
       
       
	

	  </div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'../footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
