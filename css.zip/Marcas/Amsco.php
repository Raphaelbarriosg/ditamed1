<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="../images/favicon.png">
<!-- CSS -->
<link href="../CSS/tipTip.css" rel="stylesheet" type="text/css" />

<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="../js/jquery.min.js"></script>

<script type="text/javascript" src="../js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="../js/jquery.tipTip.js"></script>
<script type="text/javascript" src="../js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - ¡Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'../menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro">
        
        
        <br /> 
        <h1  align="center">AMSCO</h1><center>
          <p>&nbsp;</p>
          <table width="700" border="0">
            <tr>
              <td width="325"><h2 align="center">Amsco 3011</h2></td>
              <td width="365"><h2 align="center"> Especificaciones</h2></td>
            </tr>
            <tr>
              <td><img src="../images/productos/8.jpg" alt="" width="276" height="286" /></td>
              <td align="justify"> 
              
                  <h4>&nbsp;&nbsp;&nbsp;&nbsp;Amsco 3011,  Gravedad sola puerta Autoclave Esterilizador Diseñado  para la esterilización de líquidos en frascos con cierres están provistos, a 250 grados F (122 grados C), y también de calor y humedad estable mercancías en 270 grados F (132grados C) Renovado 16 &quot;x 16&quot; x 26 &quot;y presión de la cámara<br />
                    Puerta de brazo radial con cremallera y dos estantes Columna de control incluye un fácil de leer pantalla fluorescente al vacío Impresora térmica integral.</h4>
               
                <p>&nbsp;</p>
                <p>&nbsp;</p></td>
            </tr>
          </table>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </center>

<br /> 
<p align="center"><a href="javascript:history.back(1)" class="someClass" title="Regresar a la pagina anterior" >&lt;&lt; Regresar</a></p>
<br />
<br /> 
        
        </div>
       
       
       
       
       
       
       
       
	

	  </div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'../footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
