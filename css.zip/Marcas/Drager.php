<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="../images/favicon.png">
<!-- CSS -->
<link href="../CSS/tipTip.css" rel="stylesheet" type="text/css" />

<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="../js/jquery.min.js"></script>

<script type="text/javascript" src="../js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="../js/jquery.tipTip.js"></script>
<script type="text/javascript" src="../js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - &iexcl;Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'../menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro">
        <br />
        
          <h1 align="center">Dräger</h1>

        <p>&nbsp;</p>
        <table width="700" border="0" align="center" class="tabla">
          <tr>
            <td width="389"><h2>Asistente personal de anestesia</h2></td>
            <td width="301"><h2>Especificaciones</h2></td>
          </tr>
          <tr>
            <td><img src="../images/productos/17.jpg" alt="" width="310" height="267" /></td>
            <td><br /><br><p align="justify">La estación Dräger Primus ha sido diseñada para ser su asistente personal de anestesia. Es una combinación de diseño comprobado a lo largo del tiempo con una tecnología de vanguardia, creada para satisfacer la demanda de una solución de anestesia completa e innovadora en el entorno médico actual, el cual es cada vez más complejo.</p>
              <p align="justify">La estación Dräger Primus permite monitorizar los parámetros de la función pulmonar y la ventilación en una amplia pantalla TFT a color de 12,1&quot;, configurable por el usuario. Su diseño de arquitectura abierta proporciona la opción de agregar pantallas adicionales, permitiendo ampliar su capacidad de monitorización para incluir parámetros hemodinámicos entre otros.</p></td>
          </tr>
        </table>
        <p><br /> 
          
        </p>
        <p align="center">&nbsp; </p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center"><a href="javascript:history.back(1)" class="someClass" title="Regresar a la pagina anterior" >&lt;&lt; Regresar</a></p>
<p>&nbsp;</p>
        </div>
       
       
       
       
       
       
       
       
	

	  </div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'../footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
