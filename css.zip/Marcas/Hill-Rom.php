<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="../images/favicon.png">
<!-- CSS -->
<link href="../CSS/tipTip.css" rel="stylesheet" type="text/css" />

<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="../js/jquery.min.js"></script>

<script type="text/javascript" src="../js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="../js/jquery.tipTip.js"></script>
<script type="text/javascript" src="../js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - &iexcl;Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'../menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro">
        
        
        <p>&nbsp;</p>
        <h1 align="center">HILL-ROM</h1>
        <p><br /> 
        </p>
        <table width="721" border="0">
          <tr>
            <td width="336" align="center"><h2>Affinity P3700</h2>              </td>
            <td width="375"><h2 align="center">Especificaciones</h2></td>
          </tr>
          <tr>
            <td><br /><br /><img src="../images/productos/5.jpg" alt="" width="286" height="373" /></td>
            <td><p>&nbsp;</p>
              <p><br /> 
                Longitud total 90 &quot;(228,6 cm)<br />
                La posición general de la cabecera elevada altura 53 ¼ &quot;(136 cm)<br />
                Altura total posición de salmón ahumado 18 ½ &quot;(47 cm)<br />
                Posición de la altura total de alta 35 ¾ &quot;(91,44 cm)<br />
                Total de los viajes Cotizaciones 17 ¼ &quot;(44.45 cm)<br />
                Ancho total 34 &quot;(86,4 cm)<br />
                Baranda longitud 28 &quot;(71 cm)<br />
                Dentro de Liquidación barandas 38 &quot;(96,5 cm)<br />
                Baranda altura de 13 &quot;(33 cm)<br />
                Tamaño del colchón 34 &quot;x 78&quot; x 4 &quot;(86,4 cm x 198 cm x 10 cm)<br />
                Caster rueda de 6 &quot;(15,2 cm)<br />
                Distancia entre ejes, de centro a centro de la longitud 50 &quot;(127cm)<br />
                Distancia entre ejes, centro a centro de cabecera ancho de 24.5 &quot;(64.5cm)<br />
                Distancia entre ejes, de centro a centro de parte de los pies ancho de 29,5 &quot;(75 cm)<br />
                Liquidación en la posición de base de alta 5 &quot;(12,7 cm)<br />
                Liquidación en la posición de base baja de 2,5 &quot;(6,35 cm)<br />
                Trendelenburg ángulo de inclinación de 8<br />
                El peso máximo del paciente 500 libras (227 kg)<br />
                Sección de alimentos, el peso de elevación máxima de 400 libras (181.6 kg)<br />
              Sección de la cabeza, levantar peso máximo 200 libras (91 kg) </p></td>
          </tr>
      </table>
        <p>&nbsp;</p>
        <h1  align="center">&nbsp;</h1><center>
        </center>

<br /> 
<br />
<p align="center"><a href="javascript:history.back(1)" class="someClass" title="Regresar a la pagina anterior" >&lt;&lt; Regresar</a></p>
<br /> 
<br /> 
<br /> 
        
        </div>
       
       
       
       
       
       
       
       
	

	  </div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'../footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
