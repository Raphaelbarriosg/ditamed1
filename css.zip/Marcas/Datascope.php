<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="../images/favicon.png">
<!-- CSS -->
<link href="../CSS/tipTip.css" rel="stylesheet" type="text/css" />

<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="../js/jquery.min.js"></script>

<script type="text/javascript" src="../js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="../js/jquery.tipTip.js"></script>
<script type="text/javascript" src="../js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - ¡Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'../menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro"><br /> 
        <h1  align="center">DATASCOPE </h1>
        <p  align="center">&nbsp;</p>
        <center>
        </center>

        <table width="700" border="0" align="center">
          <tr>
            <td width="319"><h2 align="center">Datascope Spectrum </h2></td>
            <td width="371"><h2 align="center">Especificaciones</h2></td>
          </tr>
          <tr>
            <td><br /><br /><img src="../images/productos/6.jpg" alt="" width="282" height="363" /></td>
            <td><br /><br />
              <p>Monitor de Parametros Vitales: ECG, Respiracion, Presion No Invasiva, SpO2, Temperatura, Calculo de drogas y Capnografia. Pantalla color: 12.1\&quot;, Resolucion de 800 x 600, visualizacion de hasta 8 formas de onda, Peso: 6 Kg. Para pacientes adultos, pediátricos y neonatales. Hasta 500 Tendencias completas graficas y numericas de todos los parametros. Oxicardiograma para aplicaciones neonatales y pediátricas. Autonomía: 4hs con medición de ECG, SpO2 y PNI cada 15 minutos. Selecciones uno de los parámetros adicionales para cumplir con las exigencias de sus servicio: Microstream CO2, modulo de análisis cardiaco View 12, Saturación Nellcor Oximart, Gasto cardiaco, presión arterial invasiva adicional, análisis de ST y arritmias, registro de 2 canales y análisis de agentes anestésicos, CO2, O2 y N2O con el Gas Module II. Compatible con la central de monitoreo. El modulo externo dispone de todas las herramientas que necesita, pero sin sacrificar su transportabilida de incluye gasto cardiaco, una presión invasiva adicional y una segunda temperatura.</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
            
              
             </td>
          </tr>
        </table>
        <br /> 
<p align="center"><a href="javascript:history.back(1)" class="someClass" title="Regresar a la pagina anterior" >&lt;&lt; Regresar</a></p>
<br /> 
<br /> 
<br /> 
        
        </div>
       
       
       
       
       
       
       
       
	

	  </div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'../footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
