<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="../images/favicon.png">
<!-- CSS -->
<link href="../CSS/tipTip.css" rel="stylesheet" type="text/css" />

<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="../js/jquery.min.js"></script>

<script type="text/javascript" src="../js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="../js/jquery.tipTip.js"></script>
<script type="text/javascript" src="../js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - &iexcl;Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'../menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro">
        
        
        <p>&nbsp;</p>
        <h1 align="center">Mindray<br /> 
        </h1>
<h1  align="center">&nbsp;</h1>
        <table width="700" border="0">
          <tr>
            <td width="288" align="center"><h2> BENE-VIEW    T8</h2></td>
            <td width="402"><h2 align="center">Especificaciones</h2></td>
          </tr>
          <tr>
            <td><p>&nbsp;</p>
              <p>&nbsp;</p>
              <p><img src="../images/productos/18.PNG" alt="" width="270" height="303" /></p></td>
            <td align="justify"> &nbsp;&nbsp;&nbsp; La serie BeneView de monitores de pacientes ofrece una amplia gama de posibilidades de monitorización de pacientes para todos los niveles de gravedad de los pacientes y todas las unidades de cuidados. Gracias a su gran funcionalidad, su flexible configuración y su diseño modular, la serie BeneView ofrece a los equipos de las unidades de cuidados más información de la que necesitan, tanto como monitor de cabecera como durante el transporte. El módulo multiparámetros es capaz de almacenar hasta 24 horas de datos y permite la continuidad de los datos entre diferentes monitores durante la estancia de un paciente. La pantalla táctil de alta resolución y la distribución definida por el usuario ofrecen la visibilidad y la aptitud de uso necesarias para todas las aplicaciones. Además, la serie BeneView dispone de funciones de extraordinario valor, como por ejemplo, su gran capacidad de almacenamiento de datos, la pantalla independiente y el software de gestión de datos. </td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <p  align="center">&nbsp;</p>
        <center>
        </center>

<br /> 
<p align="center"><a href="javascript:history.back(1)" class="someClass" title="Regresar a la pagina anterior" >&lt;&lt; Regresar</a></p>
<br /> 
<br /> 
<br /> 
        
        </div>
       
       
       
       
       
       
       
       
	

	  </div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'../footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
