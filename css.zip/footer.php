<div id="footer">
	<p>		
		
        Av universidad esquina San Francisco a sociedad, edificio centro mercantil San Francisco piso 1 oficina 13, Caracas – Venezuela.<br />
        Telf. 0212-481-99-70 / 0212-484-40-01 /  <br />
        <p> DITAMED ¡EQUIPOS MEDICOS! <font color="#FF0000">RIF-J-29889801-1</font></p>

				
	</div>	