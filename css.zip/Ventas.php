<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="images/favicon.png">
<!-- CSS -->
<link rel="stylesheet" href="css/estilo.css" type="text/css" />

<link href="CSS/tipTip.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="js/jquery.min.js"></script>

<script type="text/javascript" src="js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="js/jquery.tipTip.js"></script>
<script type="text/javascript" src="js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - &iexcl;Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro">
          <h2 align="center"><strong>Departamentos de venta</strong></h2>
         
                <p align="justify">Conformado por profesionales con amplia experiencia para brindar accesoria en la dotación de equipos médicos de las mejores marcas del mercado, accesorios, consumibles y un amplio catalogo en equipos de salud ocupacional y equipos de medición ambiental. pues contamos con el apoyo de las mejores casas comerciales pioneras a nivel mundial tales como: WelchAllyn, Unico, Hill room, GE, Steris, Datex Ohmeda, Mindray, Penlon. <br />
                   <br />
                  Ofrecemos contratos de mantenimientos a plazos :<br />
                  6 meses<br />
                  12 meses <br />
Alarga la vida útil de tus equipos con nosotros.<br />
También realizamos verificación, calibración e inducción de equipos médicos y medición para seguridad laboral.<br />
                </p>
          <p><br />
      </p>
        </div>
       
       
       
       
       
       
       
       
	

	  </div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
