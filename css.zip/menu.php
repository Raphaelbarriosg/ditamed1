<div  id="menu">
		<ul>

			<li><a href="http://www.ditamed.net/index.php" class="someClass" title="Inicio">Inicio</a></li>
			<li><a href="http://www.ditamed.net/Quienes-somos.php" class="someClass" title="¿Quiénes somos?">¿Quiénes somos?</a></li>
			<li><a href="http://www.ditamed.net/Ventas.php" class="someClass"  title="Ventas">Ventas</a></li>
			<li><a href="http://www.ditamed.net/Servicio-tecnico.php" class="someClass"  title="Servicio Técnico">Servicio Técnico</a></li>
			<li><a href="http://www.ditamed.net/Marcas.php" class="someClass"  title="Marcas">Marcas</a></li>		
            <li><a href="http://www.ditamed.net/Contacto.php" class="someClass"  title="Contáctenos">Contáctenos</a></li>	
		</ul>
	</div>
    
