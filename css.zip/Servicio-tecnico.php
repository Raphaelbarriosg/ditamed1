<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="images/favicon.png">
<!-- CSS -->
<link rel="stylesheet" href="css/estilo.css" type="text/css" />

<link href="CSS/tipTip.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="js/jquery.min.js"></script>

<script type="text/javascript" src="js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="js/jquery.tipTip.js"></script>
<script type="text/javascript" src="js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - &iexcl;Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro">
        
        
        <br /> 
        
            <h2 align="center"><strong>DEPARTAMENTO DE SERVICIO TÉCNICO</strong></h2>
            <p align="center">&nbsp;</p>
          </blockquote>
        </blockquote>
        <p>Está conformado por Ingenieros Electrónicos, Biomédicos y Técnicos Superiores en Electromedicina, Electrónica y Mecánica Industrial, los mismos cuentan con la capacitación en las distintas líneas de equipos médicos, salud ocupacional y Equipos de medicines ambientales.</p>
        <p>La empresa cuenta con una sala técnica con equipos de medición de alta tecnología como osciloscopios, generadores de señales, fuentes de poder, frecuencímetros, probadores universales, simuladores de paciente, medidores de joules,  medidores de concentración de anestesia, vatímetros.<br />
        </p>
        <p>&nbsp;</p>
        <h2 align="center"><strong> TIPO DE EQUIPOS QUE SE REPARAN</strong></h2>
<p>&nbsp;</p>
        <p>&nbsp;</p>
        <table width="665" height="457" border="0" align="center" class="tabla">
          <tr>
            <td width="382" align="justify"> <ul>
              <li>
                Máquinas de Anestesia.</li>
                
                <li>Ventiladores Mecánicos Neonatales.</li>
                
                <li>Ventiladores Mecánicos Adulto Pediátrico.</li>
                
                <li>Mesas Quirúrgicas.</li>
                <li>Monitores de Paciente.</li>
                <li>Monitores de presión. </li>
               <li> Desfibriladores.</li>
               <li> Electrocauterios o Electro bisturíes.</li>
               <li> Electrocardiógrafos.</li>
                <li>Aspiradores de Gleras.</li>
               <li> Autoclaves.</li>
               <li> Esterilizadores.</li>
               <li> Incubadoras.</li>
                <li>Incubadoras de Transporte.</li>
                <li>Bombas de Infusión.</li>
                <li>Cardioversión con marcapasos externo.</li>
                <li>Lámparas Scialiticas.</li>
               <li> Mesas de Parto.</li>
               <li> Mesas de Reanimación.</li>
               <li> Mesas para Examen Ginecológico.</li>
               <li> Microscopios.</li>
               <li> Monitores Fetales.</li>
               <li> Nebulizadores.</li>
                <li>Tensiómetros de Pedestal, Mesa y Pared.</li>
            </ul>

            </td>
            <td width="273" id="imagen">
            <a href="Marcas/General-Electric.php" class="someClass" title="General Electric "><img src="images/marcas/1.jpg" alt="" width="50" height="50" /></a><br />
     <a href="Marcas/General-Electric.php" class="someClass" title="General Electric "><img src="images/marcas/2.jpg" alt="" width="50" height="50" /></a><br />
     <a href="Marcas/General-Electric.php" class="someClass" title="General Electric "><img src="images/marcas/3.jpg" alt="" width="50" height="50" /></a><br />
     
            
            </td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
<h1  align="center">&nbsp;</h1>
        </div>
		</div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
