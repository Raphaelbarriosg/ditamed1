<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta name="Description" content="Venta de equipos medicos" />
<meta name="Keywords" content="equipos,medicos,venezuela" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="Robots" content="index,follow" />
<link rel="shortcut icon" href="images/favicon.png">
<!-- CSS -->
<link rel="stylesheet" href="css/estilo.css" type="text/css" />

<link href="CSS/tipTip.css" rel="stylesheet" type="text/css" />

<!-- JS -->

<script type="text/javascript" src="js/jquery.min.js"></script>

<script type="text/javascript" src="js/jquery.cycle.lite.js"></script>

<script type="text/javascript" src="js/jquery.tipTip.js"></script>
<script type="text/javascript" src="js/jquery.tipTip.minified.js"></script>

<script  >$(function(){
$(".someClass").tipTip({maxWidth: "auto", edgeOffset: 10});
});</script>


<script type="text/javascript">
$(document).ready(function() { //funcion para documento listo
    $('.banner').cycle({ //nombre de la capa
		fx: 'fade' // Efecto a utilizar
	});
});
</script>


<title>Ditamed - &iexcl;Equipos medicos!</title>
	
</head>

<body>
<!-- wrap starts here -->
<div id="wrap">
		<div id="todo">
	<!--header -->
	<div id="header">			
				
		<h1 id="logo-text">&nbsp;</h1>
	</div>
		
	<!-- navigation -->	
	<?php include'menu.php'	?>				
			
	<!-- content-wrap starts here -->
	<div id="content-wrap">
		
		<div id="main">
        
        <div id="dentro">
        
        
        <br /> 
        <h1  align="center">Lista de las mejores marcas para tu salud.<br /> 
<br /> 
<br /> 
        </h1>
        <center>
  <div id="imagen" class="imagen">
<table width="522" align="center" class="tabla">
  <tr>
    <td width="204"><a href="Marcas/General-Electric.php" class="someClass" title="General Electric "><img src="images/marcas/1.jpg" alt="" width="50" height="50" /></a></td>
    <td width="211"><a href="Marcas/Steris.php " class="someClass" title="Steris " ><img src="images/marcas/2.jpg" alt="" width="120" height="120" /></a></td>
  </tr>
  <tr>
    <td><a href="Marcas/Mindray.php" class="someClass" title="Mindray" ><img src="images/marcas/3.jpg" alt="" width="130" height="131" /></a></td>
    <td><a href="Marcas/Drager.php" class="someClass" title="Dräger" ><img src="images/marcas/4.png" alt="" width="744" height="310" /></a></td>
  </tr>
  <tr>
    <td><a href="Marcas/Datascope.php" class="someClass" title="Datascope" ><img src="images/marcas/5.jpg" alt="" width="177" height="110" /></a></td>
    <td><a href="Marcas/Amsco.php" class="someClass" title="Amsco" ><img src="images/marcas/6.jpg" alt="" width="188" height="95" /></a></td>
  </tr>
  <tr>
    <td><a href="Marcas/Hill-Rom.php" class="someClass" title="Hill-Rom " ><img src="images/marcas/7.jpg" alt="" width="560" height="170" /></a></td>
    <td>&nbsp;</td>
  </tr>
</table>
</div>
</center>

<br /> 
<br /> 
<br /> 
<br /> 
        
        </div>
       
       
       
       
       
       
       
       
	

	  </div>

	  <!-- content-wrap ends here -->	
	</div>
					
	<!--footer starts here-->
	<?php include'footer.php'?>		

<!-- wrap ends here -->
</div>
</div>
</body>
</html>
